var example=angular.module('starter', ['ionic', 'ngCordova']);

example.controller("ExampleController", function($scope, $cordovaContacts) {

    $scope.getContactList = function() {
        $cordovaContacts.find({filter: ''}).then(function(result) {
            $scope.contacts = result;
        }, function(error) {
            console.log("ERROR: " + error);
        });
    }

    $scope.createContact = function() {
        $cordovaContacts.save({"displayName": "Steve Jobs"}).then(function(result) {
            console.log(JSON.stringify(result));
        }, function(error) {
            console.log(error);
        });
    }

    $scope.removeContact = function() {
        $cordovaContacts.remove({"displayName": "Steve Jobs"}).then(function(result) {
            console.log(JSON.stringify(result));
        }, function(error) {
            console.log(error);
        });
    }

});